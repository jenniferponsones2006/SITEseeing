<?php
if (!defined('SITESEEING')) { http_response_code(403); exit; }
function signup(array $data): array {
    rate_limit('signup', 6); $db = database();
    $name = field($data,'name'); $address = email_field($data); $hash = hash_password(password_field($data));
    $challenge = bin2hex(random_bytes(32)); $code = str_pad((string)random_int(0,999999),6,'0',STR_PAD_LEFT); $now = time();
    transaction($db, function () use ($db,$name,$address,$hash,$challenge,$code,$now) {
        require_value(!execute_query($db,'SELECT id FROM users WHERE email=?',[$address])->fetch(), 'An account already uses this email. Please log in.', 409);
        $old = execute_query($db,'SELECT * FROM signup_challenges WHERE email=? FOR UPDATE',[$address])->fetch();
        require_value(!$old || $old['last_sent'] <= $now-60, 'Wait one minute before requesting another code.',429);
        if ($old) {
            execute_query($db,"UPDATE mail_queue SET state='obsolete' WHERE kind='verification' AND related_id=?",[$old['id']]);
            execute_query($db,'DELETE FROM signup_challenges WHERE id=?',[$old['id']]);
        }
        execute_query($db,'INSERT INTO signup_challenges(id,name,email,password_hash,code_hash,expires_at,last_sent) VALUES(?,?,?,?,?,?,?)',
            [$challenge,$name,$address,$hash,signature($challenge,$code),$now+600,$now]);
        verification_mail($db,$challenge,$address,$code);
    });
    deliver_pending(1,'verification',$challenge);
    return ['challengeId'=>$challenge,'email'=>$address,'emailMode'=>config()['email_mode'] === 'local' ? 'local' : 'smtp'];
}
function verify_signup(array $data): array {
    rate_limit('verify',30); $db = database(); $challenge = field($data,'challengeId',80); $code = field($data,'code',6,6);
    require_value((bool)preg_match('/^[0-9]{6}$/',$code),'Enter the six-digit code.');
    $result = transaction($db, function () use ($db,$challenge,$code) {
        $row = execute_query($db,'SELECT * FROM signup_challenges WHERE id=? FOR UPDATE',[$challenge])->fetch();
        require_value((bool)$row,'This signup code is no longer valid.',410);
        require_value($row['expires_at'] > time(),'Your code expired. Resend it or start signup again.',410);
        require_value($row['attempts'] < 5,'Too many incorrect codes. Start signup again.',429);
        if (!hash_equals($row['code_hash'],signature($challenge,$code))) {
            execute_query($db,'UPDATE signup_challenges SET attempts=attempts+1 WHERE id=?',[$challenge]);
            return null; // Commit the failed attempt before returning the error.
        }
        try {
            execute_query($db,"INSERT INTO users(name,email,password_hash,role,verified_at,created_at) VALUES(?,?,?,'customer',?,?)",[$row['name'],$row['email'],$row['password_hash'],time(),time()]);
        } catch (PDOException $error) {
            if ($error->getCode() === '23000') { throw new ApiError(409,'This email already has an account. Please log in.'); }
            throw $error;
        }
        $id = $db->lastInsertId();
        execute_query($db,'DELETE FROM signup_challenges WHERE id=?',[$challenge]);
        execute_query($db,"DELETE FROM mail_queue WHERE kind='verification' AND related_id=?",[$challenge]);
        return execute_query($db,'SELECT * FROM users WHERE id=?',[$id])->fetch();
    });
    require_value($result !== null,'Incorrect verification code.');
    return login_session($result);
}
function resend_code(array $data): array {
    $db = database(); $challenge = field($data,'challengeId',80); rate_limit('resend',5,3600,$challenge);
    $code = str_pad((string)random_int(0,999999),6,'0',STR_PAD_LEFT); $now = time();
    transaction($db,function () use ($db,$challenge,$code,$now) {
        $row = execute_query($db,'SELECT * FROM signup_challenges WHERE id=? FOR UPDATE',[$challenge])->fetch();
        require_value((bool)$row,'Start signup again to request a new code.',410);
        require_value($row['attempts'] < 5,'Too many incorrect codes. Start signup again.',429);
        require_value($row['last_sent'] <= $now-60,'Wait one minute before resending.',429);
        execute_query($db,'UPDATE signup_challenges SET code_hash=?,expires_at=?,last_sent=? WHERE id=?',[signature($challenge,$code),$now+600,$now,$challenge]);
        verification_mail($db,$challenge,$row['email'],$code);
    });
    deliver_pending(1,'verification',$challenge); return ['emailMode'=>config()['email_mode']];
}
function login(array $data): array {
    rate_limit('login'); $admin = ($data['role'] ?? '') === 'admin';
    $identifier = strtolower(field($data,$admin ? 'username' : 'email',254));
    rate_limit('account-login',20,900,$identifier);
    $password = $data['password'] ?? '';
    require_value(is_string($password) && strlen($password) > 0 && strlen($password) <= 72,'Incorrect credentials.',401);
    $db = database();
    $row = execute_query($db,$admin ? "SELECT * FROM users WHERE username=? AND role='admin'" : "SELECT * FROM users WHERE email=? AND role='customer'",[$identifier])->fetch();
    // Use a valid fixed bcrypt hash for missing users so verification still performs work.
    $dummy = '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.';
    $matched = safe_password_verify($password,$row ? $row['password_hash'] : $dummy);
    require_value((bool)$row && $matched,'Incorrect email/username or password.',401);
    $latest = execute_query($db,'SELECT * FROM users WHERE id=?',[$row['id']])->fetch();
    require_value($latest['password_hash'] === $row['password_hash'],'Credentials changed. Please log in again.',401);
    return login_session($latest);
}
function change_admin_password(array $data, array $user): array {
    rate_limit('change-password',5,600,(string)$user['id']); $old = $data['currentPassword'] ?? ''; $new = password_field($data,'newPassword');
    require_value(is_string($old) && safe_password_verify($old,$user['password_hash']),'The current password is incorrect.',403);
    require_value($new !== 'admin123' && $new !== $old,'Choose a new password other than the default.');
    require_value(!config()['production'] || strlen($new) >= 12,'Use at least 12 characters for the production admin password.');
    $hash = hash_password($new); $db = database();
    $updated = transaction($db,function () use ($db,$user,$hash) {
        $current = execute_query($db,'SELECT * FROM users WHERE id=? FOR UPDATE',[$user['id']])->fetch();
        require_value($current['password_hash'] === $user['password_hash'],'Your password changed in another session.',409);
        execute_query($db,'UPDATE users SET password_hash=?,must_change_password=0,session_version=session_version+1 WHERE id=?',[$hash,$user['id']]);
        return execute_query($db,'SELECT * FROM users WHERE id=?',[$user['id']])->fetch();
    });
    return login_session($updated);
}
