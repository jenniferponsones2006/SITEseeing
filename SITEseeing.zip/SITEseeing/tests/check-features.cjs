(async () => {
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const base = require('node:path').resolve(__dirname, '..') + require('node:path').sep;
let currentUser = null;
const listeners = {};
let elements = new Map(), mobile = false;
class Element {
  constructor(tag = 'div') {
    this.tag = tag; this.html = ''; this.hidden = false; this.dataset = {};
    this.style = { overflow: '' }; this.attributes = {}; this.children = []; this.events = {};
    const classes = new Set();
    this.classList = { add(name) { classes.add(name); }, remove(name) { classes.delete(name); }, contains(name) { return classes.has(name); }, toggle(name, force) { const on = force ?? !classes.has(name); if (on) classes.add(name); else classes.delete(name); return on; } };
    this.offsetWidth = 320; this.offsetHeight = 350;
  }
  set innerHTML(value) { this.html = value; this.children = []; this.nodes = new Map(); }
  get innerHTML() { return this.html; }
  setAttribute(key, value) { this.attributes[key] = value; }
  removeAttribute(key) { delete this.attributes[key]; }
  addEventListener(name, fn) { this.events[name] = fn; }
  appendChild(child) { this.children.push(child); if (child.id) elements.set(child.id, child); }
  contains(other) { return other === this || this.children.includes(other); }
  querySelector(selector) {
    if (selector === '.preview-photo' && !this.html.includes('class="preview-photo"')) return null;
    this.nodes ||= new Map();
    if (!this.nodes.has(selector)) this.nodes.set(selector, new Element());
    return this.nodes.get(selector);
  }
  querySelectorAll() { return []; }
  reportValidity() { return this.valid !== false; }
  getBoundingClientRect() { return { left: 1100, right: 1200, top: 750, bottom: 770 }; }
  closest(selector) { return selector === '.place-preview-link' && this.dataset.previewName ? this : null; }
  focus() { (listeners.focusin || []).forEach(fn => fn({ target: this })); }
}
const document = {
  body: new Element(), head: new Element(),
  getElementById(id) { if (!elements.has(id)) elements.set(id, new Element()); return elements.get(id); },
  querySelector(selector) { return this.getElementById('selector:'+selector); },
  querySelectorAll() { return []; },
  createElement(tag) { return new Element(tag); },
  addEventListener(event, fn) { (listeners[event] ||= []).push(fn); }
};
const sandbox = { document, URL, URLSearchParams, console, setTimeout, clearTimeout,
  setInterval() {}, innerWidth: 1280, innerHeight: 900,
  matchMedia: () => ({ matches: mobile }), MutationObserver: class { observe() {} },
  localStorage: { getItem() { return null; }, setItem() {} }, navigator: {},
  location: { href: 'http://localhost:8765/index.html' }, addEventListener() {}
};
sandbox.window = sandbox;
sandbox.crypto = require('node:crypto');
sandbox.SITEseeingAuth = {ready: Promise.resolve(), getUser:()=>currentUser, applyUser:user=>currentUser=user, openAccount:()=>sandbox.openModal('authModal')};
const context = vm.createContext(sandbox);
for (const name of ['utils.js', 'packages.js', 'site-data.js', 'preview-config.js', 'place-previews.js', 'place-ratings.js', 'script.js']) vm.runInContext(fs.readFileSync(base + name, 'utf8'), context, { filename: name });
const fields = ['attractions','activities','hotels','restaurants','malls','nearbyAttractions','transportation','emergency'];
const data = vm.runInContext('({touristSpots,tourPackages})', context);
// Tourist-card ratings: sourced entries, filtering, fractional stars, manual updates.
const ratings = sandbox.SITESEEING_PLACE_RATINGS;
assert.equal(Object.keys(ratings).length, 9);
for (const spot of data.touristSpots) {
  const entry = ratings[spot.id];
  assert.equal(entry.name, spot.name);
  assert(entry.rating >= 0 && entry.rating <= 5);
  assert.equal(entry.checkedOn, '2026-10-11');
  assert(entry.sourceUrl.startsWith('https://wanderlog.com/'));
  const html = sandbox.renderPlaceRating(spot);
  assert.equal((html.match(/class="place-rating-star"/g) || []).length, 5);
  assert(html.includes(entry.rating.toFixed(1)));
  assert(html.includes(entry.sourceUrl));
  assert(html.includes('Manually maintained snapshot'));
}
for (const [id, value] of [['placeSearch', ''], ['typeFilter', 'all'], ['priceFilter', 'all']]) document.getElementById(id).value = value;
sandbox.renderPlaces();
assert.equal((document.getElementById('placesGrid').innerHTML.match(/class="place-rating"/g) || []).length, 9);
assert(document.getElementById('placesGrid').innerHTML.includes('width:70%'));
document.getElementById('placeSearch').value = 'paco';
sandbox.renderPlaces();
assert.equal((document.getElementById('placesGrid').innerHTML.match(/class="place-rating"/g) || []).length, 1);
assert(document.getElementById('placesGrid').innerHTML.includes('Paco Park'));
document.getElementById('placeSearch').value = '';
document.getElementById('priceFilter').value = 'free';
sandbox.renderPlaces();
assert.equal((document.getElementById('placesGrid').innerHTML.match(/class="place-rating"/g) || []).length, data.touristSpots.filter(s => s.priceType === 'free').length);
const original = {...ratings[1]};
for (const rating of [null, '4.7', -1, 6, NaN, Infinity]) {
  ratings[1].rating = rating;
  assert.equal(sandbox.renderPlaceRating(data.touristSpots[0]), '');
}
ratings[1].rating = 3.2;
assert(sandbox.renderPlaceRating(data.touristSpots[0]).includes('width:20%'));
ratings[1].sourceUrl = 'javascript:alert(1)';
assert(!sandbox.renderPlaceRating(data.touristSpots[0]).includes('javascript:'));
ratings[1] = original;
sandbox.renderPackages();
assert(!document.getElementById('packagesGrid').innerHTML.includes('class="place-rating"'));
const configBackup = sandbox.SITESEEING_PLACE_RATINGS;
sandbox.SITESEEING_PLACE_RATINGS = undefined;
assert.equal(sandbox.renderPlaceRating(data.touristSpots[0]), '');
sandbox.SITESEEING_PLACE_RATINGS = configBackup;
console.log('PASS: all 9 tourist-card ratings, fractional stars, filters, manual updates, invalid/missing data, source links; package cards have no ratings.');
const linkCount = html => (html.match(/class="place-preview-link"/g) || []).length;
for (const place of data.touristSpots) {
  sandbox.openPlaceDetails(place.id);
  const html = document.getElementById('placeDetailsContent').innerHTML;
  assert.equal(linkCount(html), fields.reduce((n, field) => n + place[field].length, 0), place.name);
  assert(!/<li>[^<]/.test(html), 'Each category item must be linked');
  assert(!/href="(?:javascript|data):/.test(html));
}
for (const pkg of data.tourPackages) {
  sandbox.openPackageDetails(pkg.id);
  const destination = sandbox.getPackageDestination(pkg.destination);
  assert(destination, `Missing ${pkg.destination} categories`);
  const html = document.getElementById('packageDetailsContent').innerHTML;
  const expected = fields.reduce((n, field) => n + destination[field].length, 0) + 4;
  assert.equal(linkCount(html), expected, pkg.id);
  assert(!/alt="<a/.test(html));
  assert(html.includes('onclick="startReservation()"'));
}
assert(!sandbox.createPlaceLink('<script> & "name"').includes('<script>'));
sandbox.SITESEEING_PREVIEW_CONFIG.places['Unsafe'] = { url: 'javascript:alert(1)' };
assert(sandbox.createPlaceLink('Unsafe').includes('https://www.google.com/maps/'));
function link(name, section = 'Hotels', context = 'Intramuros') {
  const element = new Element('a');
  element.dataset = { previewName: name, previewSection: section, previewService: /activities|transportation|emergency/i.test(section) ? 'true' : 'false', previewContext: context };
  element.href = 'https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent(name);
  return element;
}
function event(type, value) { (listeners[type] || []).forEach(fn => fn(value)); }
const tick = () => new Promise(resolve => setTimeout(resolve, 0));
let checks = 0;
function checkPreview(name, section, contextName) {
  const entry = link(name, section, contextName);
  entry.focus();
  const popup = elements.get('placeHoverPreview');
  assert(popup && !popup.hidden);
  assert(!popup.innerHTML.includes('preview-rating'));
  assert(!popup.innerHTML.includes('Rating unavailable'));
  assert(popup.innerHTML.includes(entry.dataset.previewService === 'true' ? 'More information' : 'View place, ratings, and review'));
  const photo = popup.innerHTML.match(/class="preview-photo" src="([^"]+)"/);
  if (photo) {
    const imageURL = photo[1];
    assert(imageURL.startsWith('http://localhost:8765/images/places/'));
    assert(fs.existsSync(base + new URL(imageURL).pathname.slice(1)), imageURL);
  } else {
    assert(entry.dataset.previewService === 'true', name);
  }
  assert(!popup.innerHTML.includes('area photo'));
  assert.equal(entry.attributes['aria-expanded'], 'true');
  assert(parseFloat(popup.style.left) >= 12 && parseFloat(popup.style.left) + 320 <= sandbox.innerWidth - 12);
  assert(parseFloat(popup.style.top) + 350 <= sandbox.innerHeight - 12);
  checks++;
  return popup;
}
for (const destination of data.touristSpots) {
  for (const field of fields) {
    const section = {nearbyAttractions: 'Nearby Attractions', malls: 'Malls / Shopping'}[field] || field;
    destination[field].forEach(name => checkPreview(name, section, destination.name));
  }
}
for (const pkg of data.tourPackages) {
  const destination = sandbox.getPackageDestination(pkg.destination);
  checkPreview(pkg.destination, 'Destination', destination.name);
  checkPreview(pkg.hotel, 'Hotels', destination.name);
  checkPreview(pkg.restaurant, 'Restaurants', destination.name);
  for (const field of fields) {
    const section = {nearbyAttractions: 'Nearby Attractions', malls: 'Malls / Shopping'}[field] || field;
    destination[field].forEach(name => checkPreview(name, section, destination.name));
  }
}
const popup = checkPreview('The Bayleaf Intramuros', 'Hotels', 'Intramuros');
assert(popup.innerHTML.includes('images/places/hotels/the-bayleaf-intramuros.webp'));
assert(!popup.innerHTML.includes('maps.googleapis.com'));
checkPreview('White Knight Hotel Intramuros', 'Hotels', 'Intramuros');
assert(popup.innerHTML.includes('images/places/hotels/white-knight-hotel-intramuros.webp'));
assert(!popup.innerHTML.includes('area photo'));
checkPreview('Manila Ocean Park', 'Nearby Attractions', 'Intramuros');
assert(popup.innerHTML.includes('images/places/destinations/manila-ocean-park.webp'));
checkPreview('Diamond Hotel', 'Hotels', 'Manila Baywalk');
assert(popup.innerHTML.includes('images/places/hotels/diamond-hotel-philippines.webp'));
checkPreview('San Agustin Church and Museum', 'Attractions', 'Intramuros');
assert(popup.innerHTML.includes('images/places/attractions/san-agustin-church.webp'));
checkPreview('NPDC Museum and Archive Gallery', 'Attractions', 'Rizal Park');
assert(popup.innerHTML.includes('images/places/attractions/npdc-museum-and-archive-gallery.webp'));
assert(!popup.innerHTML.includes('not yet been verified'));
for (const pkg of data.tourPackages) {
  assert(pkg.images.length >= 3, pkg.id);
  assert.equal(pkg.images.length, new Set(pkg.images).size, pkg.id);
  for (const src of pkg.images) assert(fs.existsSync(base+src), src);
}
event('keydown', {key:'Escape',preventDefault(){}});
assert(popup.hidden);
checkPreview('The Bayleaf Intramuros', 'Hotels', 'Intramuros');
event('scroll', {target:document.body}); assert(popup.hidden);
mobile = true; sandbox.innerWidth = 390; sandbox.innerHeight = 844;
const mobileLink = link('The Bayleaf Intramuros');
let prevented = false;
event('click', {target:mobileLink,preventDefault(){prevented=true;}});
assert(prevented && !popup.hidden);
assert(parseFloat(popup.style.left) + 320 <= 378);
assert(parseFloat(popup.style.top) + 350 <= 832);
popup.querySelector('.preview-close').events.click(); assert(popup.hidden);
for (const source of ['place-previews.js','preview-config.js']) {
  const content = fs.readFileSync(base+source,'utf8');
  assert(!/googleMapsApiKey|importLibrary|fetchLiveData|reviewCount/.test(content));
}
console.log('PASS: '+checks+' previews across 9 places and 30 packages; all named photos and carousel paths exist; no area-photo fallback; exact CTA; no scores/API requests; aliases; keyboard and touch dismissal; viewport bounds.');

// Detail modal dismissal, persistent controls, nested modal scroll lock, focus return.
sandbox.closeModal('packageModal');
sandbox.closeModal('placeModal');
const trigger = new Element('button');
trigger.isConnected = true;
let restoredFocus = 0;
trigger.focus = () => { restoredFocus++; };
document.activeElement = trigger;
const placeModal = document.getElementById('placeModal');
placeModal.querySelector('.details-modal-body').scrollTop = 250;
sandbox.openPlaceDetails(1);
assert(placeModal.classList.contains('show'));
assert.equal(placeModal.querySelector('.details-modal-body').scrollTop, 0);
assert.equal(document.body.style.overflow, 'hidden');
const detailPopup = checkPreview('The Bayleaf Intramuros', 'Hotels', 'Intramuros');
event('keydown', {key:'Escape',preventDefault(){}});
assert(!placeModal.classList.contains('show'));
assert(detailPopup.hidden);
assert.equal(document.body.style.overflow, '');
assert.equal(restoredFocus, 1);
sandbox.openPlaceDetails(1);
sandbox.openPackageDetails(data.tourPackages[0].id);
event('keydown', {key:'Escape',preventDefault(){}});
assert(!document.getElementById('packageModal').classList.contains('show'));
assert(placeModal.classList.contains('show'));
assert.equal(document.body.style.overflow, 'hidden');
event('keydown', {key:'Escape',preventDefault(){}});
assert(!placeModal.classList.contains('show'));
assert.equal(document.body.style.overflow, '');
sandbox.openPlaceDetails(1);
event('keydown', {key:'Enter',preventDefault(){}});
assert(placeModal.classList.contains('show'));
sandbox.closeModal('placeModal'); // Same handler as X and backdrop.
assert(!placeModal.classList.contains('show'));
assert.equal(document.body.style.overflow, '');
event('keydown', {key:'Escape',preventDefault(){}}); // No details open: no-op.
const indexSource = fs.readFileSync(base+'index.html','utf8');
assert.equal((indexSource.match(/class="details-modal-header"/g)||[]).length, 2);
assert(indexSource.includes('aria-label="Close place details"'));
assert(indexSource.includes('aria-label="Close package details"'));
const styleSource = fs.readFileSync(base+'style.css','utf8');
assert(styleSource.includes('.details-modal-body {'));
assert(styleSource.includes('.details-modal-header .details-close-btn {'));
console.log('PASS: Escape closes place/package details; X handlers close details; photo previews close; scroll unlocks correctly; other keys do not close; focus returns; both headers are outside scrolling bodies.');

// Booking and carousel regressions use deterministic timers.
const scheduled = new Map(), intervals = new Map();
let timerId = 0;
sandbox.setTimeout = (fn, delay) => { const id = ++timerId; scheduled.set(id, {fn,delay}); return id; };
sandbox.clearTimeout = id => scheduled.delete(id);
sandbox.setInterval = (fn, delay) => { const id = ++timerId; intervals.set(id, {fn,delay}); return id; };
sandbox.clearInterval = id => intervals.delete(id);
const setValues = values => Object.entries(values).forEach(([id, value]) => { document.getElementById(id).value = value; });
const closeAll = () => vm.runInContext('for (const id of [...openModalOrder]) closeModal(id)', context);
const state = expression => vm.runInContext(expression, context);
const submit = id => document.getElementById(id).events.submit({preventDefault(){}});
const utils = sandbox.SITEseeingUtils;

assert.equal(utils.localDate(new Date('2026-10-11T00:15:00Z')), '2026-10-11');
assert.equal(utils.localDate(new Date('2026-10-11T23:15:00Z')), '2026-10-12');
assert.equal(utils.escapeHTML('<img src=x> " &'), '&lt;img src=x&gt; &quot; &amp;');
assert.equal(utils.isTourDate('2099-99-99'), false);
assert.equal(utils.isTourDate('2099-02-30'), false);
closeAll();
sandbox.openPackageDetails(data.tourPackages[0].id);
await sandbox.startReservation();
assert(document.getElementById('authModal').classList.contains('show'));
assert.equal(state('pendingPackage.id'), data.tourPackages[0].id);
const enteredName = 'Lu " <img src=x onerror=alert(1)>';
currentUser = {id:1, name:enteredName, email:'lu@example.com', role:'customer'};
sandbox.closeModal('authModal');
sandbox.resumeReservationAfterLogin();
assert(document.getElementById('reservationModal').classList.contains('show'));
assert.equal(state('pendingPackage'), null);
assert(!document.getElementById('reservationContent').innerHTML.includes('<img src=x'));
assert(document.getElementById('reservationContent').innerHTML.includes('&lt;img'));
assert(document.getElementById('reservationContent').innerHTML.includes('readonly'));

const validBooking = {
  reservationName: enteredName, reservationEmail:'lu@example.com', reservationDate:utils.localDate(),
  reservationGuests:'2', paymentMethod:'GCash'
};
for (const guests of ['0', '-1', '1.5', 'Infinity', '9007199254740991']) {
  setValues({...validBooking, reservationGuests:guests}); sandbox.continueToPayment();
  assert.equal(state('pendingReservation'), null);
  assert(document.getElementById('reservationModal').classList.contains('show'));
}
for (const date of ['2000-01-01', '2027-02-30', 'not-a-date']) {
  setValues({...validBooking, reservationDate:date}); sandbox.continueToPayment();
  assert.equal(state('pendingReservation'), null);
}
setValues({...validBooking, paymentMethod:'Unsupported'}); sandbox.continueToPayment();
assert.equal(state('pendingReservation'), null);
setValues(validBooking); document.getElementById('reservationForm').valid = false;
sandbox.continueToPayment(); assert.equal(state('pendingReservation'), null);
document.getElementById('reservationForm').valid = true;
setValues(validBooking); sandbox.updateReservationTotal();
assert.equal(document.getElementById('reservationTotal').textContent, utils.formatPrice(data.tourPackages[0].price * 2));
submit('reservationForm');
assert(document.getElementById('paymentModal').classList.contains('show'));
assert(!document.getElementById('paymentContent').innerHTML.includes('<img src=x'));
assert.equal(state('pendingReservation.guests'), 2);
assert.equal(state('pendingReservation.total'), data.tourPackages[0].price * 2);
sandbox.backToReservation();
const restored = document.getElementById('reservationContent').innerHTML;
assert(restored.includes('value="2"'));
assert(restored.includes(`value="${validBooking.reservationDate}"`));
assert(restored.includes('value="lu@example.com"'));
assert.equal(document.getElementById('paymentMethod').value, 'GCash');
assert(document.getElementById('reservationModal').classList.contains('show'));

// A server failure keeps the review and request key; retry saves exactly once.
setValues({...validBooking, paymentMethod:'Cash'}); sandbox.continueToPayment();
const sent = [], bookings = [];
let failed = true;
sandbox.SITEseeingAPI = {request: async (path, options) => {
    sent.push(options.body);
    if (failed) throw new Error('Server unavailable');
    const booking = {...options.body, bookingId:'SITE-TEST', paymentStatus:'Pay at Venue', emailStatus:'local'};
    bookings.push(booking); return {booking};
}};
await sandbox.confirmPayment();
assert(document.getElementById('paymentModal').classList.contains('show'));
assert(state('pendingReservation'));
failed = false; await sandbox.confirmPayment();
assert(document.getElementById('successModal').classList.contains('show'));
assert.equal(bookings.length,1);
assert.equal(sent[0].requestKey,sent[1].requestKey);
assert.equal(bookings[0].paymentStatus,'Pay at Venue');
assert.equal(bookings[0].guests,2);
assert(document.getElementById('successContent').innerHTML.includes('saved in the private'));
await sandbox.confirmPayment(); assert.equal(bookings.length,1);
closeAll();

// Mobile menu state clears fully instead of leaving inline positioning styles.
sandbox.toggleMobileMenu();
assert(document.querySelector('.nav-links').classList.contains('is-open'));
assert.equal(document.querySelector('.mobile-menu-btn').attributes['aria-expanded'], 'true');
sandbox.closeMobileMenu();
assert(!document.querySelector('.nav-links').classList.contains('is-open'));
assert.equal(document.querySelector('.mobile-menu-btn').attributes['aria-expanded'], 'false');
assert.equal(Object.keys(document.querySelector('.nav-links').style).length, 1); // only mock overflow default
document.body.style.overflow = 'scroll'; sandbox.openPlaceDetails(1); sandbox.closeModal('placeModal');
assert.equal(document.body.style.overflow, 'scroll'); document.body.style.overflow = '';

// Only active package covers receive src initially. Remaining photo order is unchanged.
const grid = document.getElementById('packagesGrid');
sandbox.renderPackages();
assert.equal((grid.innerHTML.match(/\sdata-src=/g)||[]).length, data.tourPackages.reduce((n,p)=>n+p.images.length-1,0));
assert.equal((grid.innerHTML.match(/\ssrc=/g)||[]).length, data.tourPackages.length);
const card = new Element(), media = new Element();
const slides = Array.from({length:4},(_,i) => { const img = new Element('img'); if(i) img.dataset.src = `photo-${i+1}.jpg`; return img; });
slides[0].classList.add('active');
const dots = Array.from({length:4},()=>new Element());
card.querySelector = () => media;
media.querySelectorAll = selector => selector === 'img' ? slides : dots;
grid.querySelectorAll = () => [card];
sandbox.renderPackages();
card.events.mouseenter();
assert.equal(intervals.size, 1);
assert.equal(slides[1].src, 'photo-2.jpg');
assert(slides[1].classList.contains('active'));
card.events.mouseleave(); assert.equal(intervals.size, 0); assert(slides[0].classList.contains('active'));
card.events.mouseenter(); assert.equal(intervals.size, 1);
sandbox.filterPackages('Solo', new Element('button'));
assert.equal(intervals.size, 0, 'Filtering must cancel detached carousel timers');
assert(slides[0].classList.contains('active'));
card.events.focusin(); assert.equal(intervals.size, 1);
card.events.focusout(); assert.equal(intervals.size, 0);
grid.querySelectorAll = () => [];
sandbox.filterPackages('all', new Element('button'));
sandbox.setupHero(); assert.equal(intervals.size, 1);
document.hidden = true; event('visibilitychange', {}); assert.equal(intervals.size, 0);
document.hidden = false; event('visibilitychange', {}); assert.equal(intervals.size, 1);
assert.equal(document.getElementById('heroDots').children.length, 17);
assert.equal(document.getElementById('heroDots').children[0].attributes['aria-label'], 'Show hero photo 1');
const heroDots = document.getElementById('heroDots').children;
const oldQueryAll = document.querySelectorAll;
document.querySelectorAll = selector => selector === '.hero-dot' ? heroDots : oldQueryAll.call(document, selector);
sandbox.selectHero(0);
assert.equal(heroDots[0].attributes['aria-pressed'], 'true');
document.querySelector('.hero-prev').onclick();
assert.equal(state('currentHero'), 16, 'Previous wraps to the last photo');
assert.equal(heroDots[16].attributes['aria-pressed'], 'true');
assert.equal(heroDots[0].attributes['aria-pressed'], 'false');
document.querySelector('.hero-next').onclick();
assert.equal(state('currentHero'), 0, 'Next wraps to the first photo');
heroDots[8].onclick();
assert.equal(state('currentHero'), 8);
assert(document.querySelector('.hero').style.backgroundImage.includes(state('heroImages')[8]));
assert.equal(intervals.size, 1, 'Manual selection must replace, rather than add, the timer');
[...intervals.values()][0].fn();
assert.equal(state('currentHero'), 9, 'Autoplay advances from the selected photo');
sandbox.setupHero();
assert.equal(intervals.size, 1, 'Repeated setup must not duplicate carousel timers');
assert.equal(document.getElementById('heroDots').children.length, 17);
document.hidden = true; event('visibilitychange', {});
document.querySelector('.hero-next').onclick();
assert.equal(intervals.size, 0, 'Manual navigation must not restart autoplay in a hidden tab');
document.hidden = false; event('visibilitychange', {});
assert.equal(intervals.size, 1);
document.querySelectorAll = oldQueryAll;
console.log('PASS: 17 home photos; previous/next wraparound; active dots; manual timer reset; autoplay and hidden-tab pause.');

console.log('PASS: auth-required reservation resume; escaped form/review text; Manila date/guest validation; payment Back preserves inputs; server booking save/retry; mobile menu; carousel hydration, order, cleanup, and hidden-tab pause.');

(async () => {
  const opened = [], copied = [], prompted = [];
  sandbox.open = (...args) => opened.push(args);
  sandbox.navigator.clipboard = {writeText: async value => copied.push(value)};
  sandbox.prompt = (...args) => prompted.push(args);
  sandbox.shareFacebook(); sandbox.shareTwitter(); sandbox.shareMessenger(); sandbox.shareInstagram();
  await Promise.resolve();
  assert.equal(opened.length, 4);
  assert(opened.every(args => args[2] === 'noopener,noreferrer'));
  assert(opened[0][0].includes(encodeURIComponent(sandbox.location.href)));
  assert.equal(copied.length, 2);
  delete sandbox.navigator.clipboard;
  assert.equal(await sandbox.copyLink(), false);
  assert.equal(prompted[0][1], sandbox.location.href);
  console.log('PASS: all share handlers exist; encoded share links; Messenger/Instagram copy workflow; clipboard fallback.');
})().catch(error => { console.error(error); process.exitCode = 1; });

})().catch(error => { console.error(error); process.exitCode = 1; });
