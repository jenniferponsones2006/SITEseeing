<?php
// Live local smoke test. Requires Apache, imported SQL, and local email mode.
// Creates one verified test user and reservation; run only on a disposable test database.
if (PHP_SAPI !== 'cli') { http_response_code(403); exit; }
define('SITESEEING',true);
require dirname(__DIR__) . '/backend/bootstrap.php';
$c = config();
if ($c['production'] || $c['email_mode'] !== 'local') { fwrite(STDERR,"Run this only against a local test database with local email mode.\n"); exit(1); }
$base = rtrim($c['site_url'],'/'); $cookie = ''; $csrf = '';
function api_request(string $route, string $method = 'GET', ?array $body = null): array {
    global $base,$cookie,$csrf;
    $origin = parse_url($base); $origin = $origin['scheme'] . '://' . $origin['host'] . (isset($origin['port']) ? ':' . $origin['port'] : '');
    $headers = ['Content-Type: application/json','X-SITEseeing-Request: 1','Origin: ' . $origin];
    if ($cookie !== '') { $headers[] = 'Cookie: ' . $cookie; }
    if ($csrf !== '') { $headers[] = 'X-CSRF-Token: ' . $csrf; }
    $options = ['method'=>$method,'header'=>implode("\r\n",$headers),'ignore_errors'=>true,'timeout'=>30];
    if ($body !== null) { $options['content'] = json_encode($body,JSON_THROW_ON_ERROR); }
    $raw = file_get_contents($base . '/api.php?route=' . urlencode($route),false,stream_context_create(['http'=>$options]));
    if ($raw === false) { throw new RuntimeException('Cannot reach Apache.'); }
    foreach ($http_response_header as $header) {
        if (stripos($header,'Set-Cookie: siteseeing_session=') === 0) { $cookie = explode(';',substr($header,12))[0]; }
    }
    $status = (int)explode(' ',$http_response_header[0])[1];
    $data = json_decode($raw,true,512,JSON_THROW_ON_ERROR);
    if (array_key_exists('csrf',$data)) { $csrf = $data['csrf'] ?? ''; }
    return [$status,$data];
}
function ensure_test(bool $condition, string $message): void { if (!$condition) { throw new RuntimeException($message); } }
try {
    [$status] = api_request('/api/session'); ensure_test($status === 200,'Session endpoint failed.');
    [$status] = api_request('/api/admin/bookings'); ensure_test($status === 401,'Admin must require login.');
    $email = 'smoke-' . bin2hex(random_bytes(5)) . '@example.test';
    [$status,$signup] = api_request('/api/auth/signup','POST',['name'=>'Local PHP test','email'=>$email,'password'=>'test-tour-password']);
    ensure_test($status === 202,'Signup failed.');
    $mail = execute_query(database(),"SELECT body FROM mail_queue WHERE kind='verification' AND related_id=?",[$signup['challengeId']])->fetchColumn();
    preg_match('/code is: ([0-9]{6})/',$mail,$match); ensure_test(isset($match[1]),'No verification email generated.');
    [$status,$verified] = api_request('/api/auth/verify','POST',['challengeId'=>$signup['challengeId'],'code'=>$match[1]]);
    ensure_test($status === 201 && $verified['user']['email'] === $email,'Verification/login failed.');
    [$status] = api_request('/api/admin/bookings'); ensure_test($status === 403,'Customer must not access admin records.');
    $payload = ['packageId'=>'intramuros-solo','customerName'=>'Local PHP test','email'=>$email,'date'=>date('Y-m-d',time()+86400),
        'guests'=>2,'paymentMethod'=>'Cash','requestKey'=>bin2hex(random_bytes(16)),'total'=>1];
    [$status,$saved] = api_request('/api/bookings','POST',$payload);
    ensure_test($status === 201 && $saved['booking']['total'] === 5598,'Server pricing/booking failed.');
    [$status,$retry] = api_request('/api/bookings','POST',$payload);
    ensure_test($status < 300 && $retry['booking']['bookingId'] === $saved['booking']['bookingId'],'Retry duplicated the booking.');
    [$status,$mine] = api_request('/api/bookings'); ensure_test($status === 200 && count($mine['bookings']) === 1,'Booking history failed.');
    api_request('/api/auth/logout','POST',[]);
    $adminPassword = getenv('SITESEEING_TEST_ADMIN_PASSWORD') ?: 'admin123';
    [$status] = api_request('/api/auth/login','POST',['username'=>'admin','password'=>$adminPassword,'role'=>'admin']);
    ensure_test($status === 200,'Admin login failed (supply SITESEEING_TEST_ADMIN_PASSWORD if changed).');
    [$status,$records] = api_request('/api/admin/bookings');
    ensure_test($status === 200 && $records['summary']['total'] >= 1,'Admin records failed.');
    $record = api_request('/api/admin/bookings/' . $saved['booking']['id'])[1]['booking'];
    [$status,$updated] = api_request('/api/admin/bookings/' . $record['id'],'PATCH',['status'=>'Cancelled','paymentStatus'=>'Pay at Venue','version'=>$record['version']]);
    ensure_test($status === 200 && $updated['booking']['status'] === 'Cancelled','Admin editing failed.');
    echo "PASS: verified signup, sessions, role protection, server pricing, booking/email generation, duplicate prevention, and admin records/editing.\n";
} catch (Throwable $error) { fwrite(STDERR,'FAIL: ' . $error->getMessage() . "\n"); exit(1); }
