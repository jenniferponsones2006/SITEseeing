<?php
// Run with XAMPP PHP: C:\xampp\php\php.exe tests\check-helpers.php
if (PHP_SAPI !== 'cli') { http_response_code(403); exit; }
define('SITESEEING',true);
require dirname(__DIR__) . '/backend/bootstrap.php';
function check(bool $condition, string $description): void {
    if (!$condition) { fwrite(STDERR,"FAIL: $description\n"); exit(1); }
}
$hash = hash_password('tour-password-123');
check(safe_password_verify('tour-password-123',$hash),'Password verification');
check(!safe_password_verify('wrong-password',$hash),'Wrong password rejected');
check(!safe_password_verify(str_repeat('a',73),$hash),'Overlong password rejected');
check($hash !== 'tour-password-123','Password not stored as plaintext');
check(field(['name'=>'  Lu Pinlac  '],'name') === 'Lu Pinlac','Name trimmed');
check(email_field(['email'=>'LU@EXAMPLE.COM']) === 'lu@example.com','Email normalized');
try { password_field(['password'=>'short']); check(false,'Short password rejected'); } catch (ApiError $error) { check($error->status === 400,'Password validation status'); }
try { field(['name'=>"Lu\nInjected"],'name'); check(false,'Control characters rejected'); } catch (ApiError $error) { check(true,'Control character rejection'); }
try { email_field(['email'=>'bad address']); check(false,'Invalid email rejected'); } catch (ApiError $error) { check(true,'Email rejection'); }
$catalog = packages();
check(count($catalog) === 30,'30 packages loaded');
check($catalog['intramuros-solo']['price'] === 2799,'Shared catalog price');
echo "PASS: password hashing, password validation, name/email validation, and shared package catalog.\n";
