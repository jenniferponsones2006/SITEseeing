<?php
// Server configuration. Apache must deny direct access to this backend folder.
if (!defined('SITESEEING')) { http_response_code(403); exit; }
return [
    'db_host' => '127.0.0.1',
    'db_port' => 3306,
    'db_name' => 'siteseeing',
    'db_user' => 'root',
    'db_password' => '', // XAMPP local default. Use a dedicated database account on hosting.
    'site_url' => 'http://localhost/SITEseeing',
    'production' => false,
    'admin_initial_password' => 'admin123', // Only used when the first admin is created.
    'private_dir' => dirname(__DIR__) . '/private',
    'email_mode' => 'local', // local = private .eml test files; smtp = real SMTP through PHPMailer.
    'mail_from' => 'your-sender@example.com',
    'mail_from_name' => 'SITEseeing',
    'smtp_host' => '',
    'smtp_port' => 587,
    'smtp_security' => 'starttls', // starttls (usually 587) or ssl (usually 465).
    'smtp_username' => '',
    'smtp_password' => '',
];
