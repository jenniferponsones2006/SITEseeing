<?php
if (!defined('SITESEEING')) { http_response_code(403); exit; }
function queue_mail(PDO $db, string $kind, string $relatedId, string $recipient, string $subject, string $body): void {
    execute_query($db, "INSERT INTO mail_queue(kind,related_id,recipient,subject,body,next_attempt,created_at) VALUES(?,?,?,?,?,?,?) " .
        "ON DUPLICATE KEY UPDATE recipient=VALUES(recipient),subject=VALUES(subject),body=VALUES(body),state='queued',attempts=0,next_attempt=VALUES(next_attempt),lease_until=0,last_error=NULL",
        [$kind,$relatedId,$recipient,$subject,$body,time(),time()]);
}
function send_email(array $job): string {
    $c = config();
    if ($c['email_mode'] === 'local') {
        $folder = $c['private_dir'] . '/outbox';
        if (!is_dir($folder) && !mkdir($folder, 0700, true) && !is_dir($folder)) { throw new RuntimeException('LocalOutboxUnavailable'); }
        $subject = '=?UTF-8?B?' . base64_encode($job['subject']) . '?=';
        $message = "From: SITEseeing <" . $c['mail_from'] . ">\r\nTo: " . $job['recipient'] . "\r\nSubject: $subject\r\n" .
            "Date: " . gmdate('D, d M Y H:i:s') . " +0000\r\nMIME-Version: 1.0\r\nContent-Type: text/plain; charset=UTF-8\r\n" .
            "Content-Transfer-Encoding: 8bit\r\n\r\n" . str_replace("\n", "\r\n", $job['body']);
        $path = $folder . '/' . sprintf('%06d', $job['id']) . '-' . $job['kind'] . '.eml';
        if (file_put_contents($path, $message, LOCK_EX) === false) { throw new RuntimeException('LocalOutboxUnavailable'); }
        @chmod($path, 0600);
        return 'local';
    }
    $autoload = dirname(__DIR__) . '/vendor/autoload.php';
    if (!is_file($autoload)) { throw new RuntimeException('PHPMailerNotInstalled'); }
    require_once $autoload;
    $mail = new \PHPMailer\PHPMailer\PHPMailer(true);
    $mail->isSMTP(); $mail->Host = $c['smtp_host']; $mail->Port = (int)$c['smtp_port'];
    $mail->SMTPAuth = $c['smtp_username'] !== '';
    $mail->Username = $c['smtp_username']; $mail->Password = $c['smtp_password'];
    $mail->SMTPSecure = $c['smtp_security'] === 'ssl' ? 'ssl' : 'tls';
    $mail->Timeout = 15; $mail->CharSet = 'UTF-8';
    $mail->setFrom($c['mail_from'], $c['mail_from_name']); $mail->addAddress($job['recipient']);
    $mail->Subject = $job['subject']; $mail->Body = $job['body']; $mail->send();
    return 'sent';
}
function deliver_pending(int $limit = 10, ?string $kind = null, ?string $related = null): void {
    $db = database();
    for ($i = 0; $i < $limit; $i++) {
        $now = time(); $lease = $now + 180;
        $job = transaction($db, function () use ($db,$now,$lease,$kind,$related) {
            $where = "((state IN ('queued','failed') AND next_attempt<=?) OR (state='sending' AND lease_until<?))";
            $params = [$now,$now];
            if ($kind !== null && $related !== null) { $where .= ' AND kind=? AND related_id=?'; $params[] = $kind; $params[] = $related; }
            $row = execute_query($db, 'SELECT * FROM mail_queue WHERE ' . $where . ' ORDER BY id LIMIT 1 FOR UPDATE', $params)->fetch();
            if (!$row) { return null; }
            if ($row['kind'] === 'verification') {
                $active = execute_query($db, 'SELECT id FROM signup_challenges WHERE id=? AND expires_at>?', [$row['related_id'],$now])->fetch();
                if (!$active) { execute_query($db, "UPDATE mail_queue SET state='obsolete' WHERE id=?", [$row['id']]); return false; }
            }
            execute_query($db, "UPDATE mail_queue SET state='sending',lease_until=?,attempts=attempts+1 WHERE id=?", [$lease,$row['id']]);
            return $row;
        });
        if ($job === null) { return; }
        if ($job === false) { continue; }
        try { $state = send_email($job); $error = null; }
        catch (Throwable $exception) { $state = 'failed'; $error = get_class($exception); error_log('SITEseeing email delivery failed: ' . $error); }
        $retry = $now + min(3600, 30 * (2 ** min((int)$job['attempts'], 7)));
        execute_query($db, "UPDATE mail_queue SET state=?,last_error=?,next_attempt=?,lease_until=0 WHERE id=? AND state='sending' AND lease_until=?", [$state,$error,$retry,$job['id'],$lease]);
    }
}
function verification_mail(PDO $db, string $challenge, string $address, string $code): void {
    queue_mail($db,'verification',$challenge,$address,'Verify your SITEseeing email',
        "Your SITEseeing verification code is: $code\n\nIt expires in 10 minutes. Enter it on the signup screen to activate your account.\n" .
        "If you did not request an account, ignore this message. Do not share the code.\n");
}
