-- Import this file in phpMyAdmin. MySQL 5.7+/8 and XAMPP MariaDB 10.4+.
-- No fake users or bookings. PHP creates the first admin with a hashed password.
CREATE DATABASE IF NOT EXISTS siteseeing CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE siteseeing;
CREATE TABLE IF NOT EXISTS users (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(120) NOT NULL,
 email VARCHAR(254) NULL UNIQUE,
 username VARCHAR(60) NULL UNIQUE,
 password_hash VARCHAR(255) NOT NULL,
 role ENUM('customer','admin') NOT NULL,
 verified_at BIGINT NOT NULL,
 created_at BIGINT NOT NULL,
 must_change_password TINYINT(1) NOT NULL DEFAULT 0,
 session_version INT UNSIGNED NOT NULL DEFAULT 1
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS app_settings (
 name VARCHAR(64) PRIMARY KEY,
 value TEXT NOT NULL
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS signup_challenges (
 id CHAR(64) PRIMARY KEY,
 name VARCHAR(120) NOT NULL,
 email VARCHAR(254) NOT NULL UNIQUE,
 password_hash VARCHAR(255) NOT NULL,
 code_hash CHAR(64) NOT NULL,
 expires_at BIGINT NOT NULL,
 attempts INT UNSIGNED NOT NULL DEFAULT 0,
 last_sent BIGINT NOT NULL
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS bookings (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 reference VARCHAR(48) NOT NULL UNIQUE,
 user_id BIGINT UNSIGNED NOT NULL,
 package_id VARCHAR(80) NOT NULL,
 package_name VARCHAR(120) NOT NULL,
 destination VARCHAR(160) NOT NULL,
 customer_name VARCHAR(120) NOT NULL,
 email VARCHAR(254) NOT NULL,
 tour_date DATE NOT NULL,
 guests INT UNSIGNED NOT NULL,
 unit_price BIGINT UNSIGNED NOT NULL,
 total BIGINT UNSIGNED NOT NULL,
 payment_method VARCHAR(40) NOT NULL,
 payment_status ENUM('Awaiting Payment','Pay at Venue','Payment Confirmed') NOT NULL,
 status ENUM('Confirmed','Pending','Cancelled') NOT NULL DEFAULT 'Confirmed',
 created_at BIGINT NOT NULL,
 updated_at BIGINT NOT NULL,
 version INT UNSIGNED NOT NULL DEFAULT 1,
 request_key VARCHAR(80) NOT NULL,
 request_hash CHAR(64) NOT NULL,
 UNIQUE KEY booking_request (user_id,request_key),
 KEY booking_user (user_id,created_at),
 KEY booking_status_date (status,tour_date),
 CONSTRAINT booking_user_fk FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS mail_queue (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 kind ENUM('verification','booking') NOT NULL,
 related_id VARCHAR(80) NOT NULL,
 recipient VARCHAR(254) NOT NULL,
 subject VARCHAR(255) NOT NULL,
 body TEXT NOT NULL,
 state ENUM('queued','sending','sent','local','failed','obsolete') NOT NULL DEFAULT 'queued',
 attempts INT UNSIGNED NOT NULL DEFAULT 0,
 next_attempt BIGINT NOT NULL,
 lease_until BIGINT NOT NULL DEFAULT 0,
 created_at BIGINT NOT NULL,
 last_error VARCHAR(100) NULL,
 UNIQUE KEY mail_related (kind,related_id),
 KEY mail_due (state,next_attempt)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS rate_limits (
 `key` CHAR(64) PRIMARY KEY,
 window_start BIGINT NOT NULL,
 count INT UNSIGNED NOT NULL,
 KEY rate_expiry (window_start)
) ENGINE=InnoDB;
