<?php
if (!defined('SITESEEING')) { http_response_code(403); exit; }
const STATUSES = ['Confirmed','Pending','Cancelled'];
const PAYMENT_STATUSES = ['Awaiting Payment','Pay at Venue','Payment Confirmed'];
const BOOKING_SELECT = "SELECT b.*,m.state AS email_state FROM bookings b LEFT JOIN mail_queue m ON m.kind='booking' AND m.related_id=CAST(b.id AS CHAR)";
function booking_data(array $row): array {
    return ['id'=>(int)$row['id'],'bookingId'=>$row['reference'],'userId'=>(int)$row['user_id'],
        'packageId'=>$row['package_id'],'packageName'=>$row['package_name'],'destination'=>$row['destination'],
        'customerName'=>$row['customer_name'],'email'=>$row['email'],'date'=>$row['tour_date'],'guests'=>(int)$row['guests'],
        'packagePrice'=>(int)$row['unit_price'],'total'=>(int)$row['total'],'paymentMethod'=>$row['payment_method'],
        'paymentStatus'=>$row['payment_status'],'status'=>$row['status'],'createdAt'=>gmdate('c',(int)$row['created_at']),
        'version'=>(int)$row['version'],'emailStatus'=>$row['email_state'] ?? 'queued'];
}
function get_booking(int $id): array {
    $row = execute_query(database(),BOOKING_SELECT . ' WHERE b.id=?',[$id])->fetch();
    require_value((bool)$row,'Booking not found.',404); return booking_data($row);
}
function save_booking(array $data, array $user): array {
    rate_limit('book',30,600,(string)$user['id']); $db = database();
    $packageId = field($data,'packageId',80); $package = packages()[$packageId] ?? null;
    require_value($package !== null,'Select a valid package.');
    $name = field($data,'customerName'); $address = email_field($data);
    require_value($address === $user['email'],'Booking confirmations use your verified account email.');
    $date = field($data,'date',10,10); $visit = DateTimeImmutable::createFromFormat('!Y-m-d',$date);
    require_value($visit !== false && $visit->format('Y-m-d') === $date && $date >= date('Y-m-d'),'Choose today or a valid future tour date.');
    $guests = $data['guests'] ?? null;
    require_value(is_int($guests) && $guests >= 1 && $guests <= 1000,'Choose 1 to 1,000 guests.');
    $method = field($data,'paymentMethod',40);
    require_value(in_array($method,['Cash','GCash','Maya','Credit / Debit Card'],true),'Select a valid payment method.');
    $key = field($data,'requestKey',80,16);
    require_value((bool)preg_match('/^[A-Za-z0-9_-]+$/',$key),'Invalid booking request key.');
    $fingerprint = hash('sha256',json_encode([$packageId,$name,$address,$date,$guests,$method],JSON_THROW_ON_ERROR));
    $result = transaction($db,function () use ($db,$user,$key,$fingerprint,$packageId,$package,$name,$address,$date,$guests,$method) {
        // Serialize booking writes per customer; the unique request key also guards retries.
        execute_query($db,'SELECT id FROM users WHERE id=? FOR UPDATE',[$user['id']])->fetch();
        $old = execute_query($db,'SELECT id,request_hash FROM bookings WHERE user_id=? AND request_key=?',[$user['id'],$key])->fetch();
        if ($old) { require_value(hash_equals($old['request_hash'],$fingerprint),'This request key was used for a different booking.',409); return [(int)$old['id'],false]; }
        $reference = 'SITE-' . date('Ymd') . '-' . strtoupper(bin2hex(random_bytes(8))); $total = $package['price']*$guests;
        $payment = $method === 'Cash' ? 'Pay at Venue' : 'Awaiting Payment'; $now = time();
        execute_query($db,'INSERT INTO bookings(reference,user_id,package_id,package_name,destination,customer_name,email,tour_date,guests,unit_price,total,payment_method,payment_status,created_at,updated_at,request_key,request_hash) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
            [$reference,$user['id'],$packageId,$package['name'],$package['destination'],$name,$address,$date,$guests,$package['price'],$total,$method,$payment,$now,$now,$key,$fingerprint]);
        $id = (int)$db->lastInsertId();
        queue_mail($db,'booking',(string)$id,$address,'Your SITEseeing reservation ' . $reference,
            "Hi $name,\n\nYour tour reservation has been recorded.\n\nReference: $reference\nPackage: " . $package['destination'] . ' — ' . $package['name'] .
            "\nDate of visit: $date\nGuests: $guests\nTotal: PHP " . number_format($total,0,'.',',') .
            "\nPayment method: $method\nPayment status: $payment\nReservation status: Confirmed\n\nNo online payment has been charged by this website.\nKeep this reference for your tour.\n\nSITEseeing\n");
        return [$id,true];
    });
    if ($result[1]) { deliver_pending(1,'booking',(string)$result[0]); }
    return ['booking'=>get_booking($result[0])];
}
function pagination(array $query): array {
    $page = filter_var($query['page'] ?? 1,FILTER_VALIDATE_INT); $size = filter_var($query['pageSize'] ?? 8,FILTER_VALIDATE_INT);
    require_value($page !== false && $size !== false,'Invalid pagination.');
    return [max(1,$page),min(50,max(1,$size))];
}
function list_bookings(array $query): array {
    [$page,$size] = pagination($query); $db = database(); $q = trim(substr((string)($query['q'] ?? ''),0,120)); $status = $query['status'] ?? 'all';
    require_value($status === 'all' || in_array($status,STATUSES,true),'Invalid status filter.'); $where = []; $params = [];
    if ($q !== '') {
        // Use a stable explicit escape character, regardless of MySQL backslash mode.
        $pattern = '%' . str_replace(['!','%','_'],['!!','!%','!_'],$q) . '%';
        $where[] = "(b.customer_name LIKE ? ESCAPE '!' OR b.email LIKE ? ESCAPE '!' OR b.reference LIKE ? ESCAPE '!' OR b.destination LIKE ? ESCAPE '!')";
        $params = [$pattern,$pattern,$pattern,$pattern];
    }
    if ($status !== 'all') { $where[] = 'b.status=?'; $params[] = $status; }
    $suffix = $where ? ' WHERE ' . implode(' AND ',$where) : '';
    $total = (int)execute_query($db,'SELECT COUNT(*) FROM bookings b' . $suffix,$params)->fetchColumn();
    $page = min($page,max(1,(int)ceil($total/$size))); $offset = ($page-1)*$size;
    // Only validated integers are interpolated for LIMIT/OFFSET (native PDO otherwise binds strings).
    $rows = execute_query($db,BOOKING_SELECT . $suffix . " ORDER BY b.id DESC LIMIT $size OFFSET $offset",$params)->fetchAll();
    $summary = ['total'=>0,'confirmed'=>0,'pending'=>0,'cancelled'=>0];
    foreach (execute_query($db,'SELECT status,COUNT(*) AS count FROM bookings GROUP BY status')->fetchAll() as $row) {
        $summary[strtolower($row['status'])] = (int)$row['count']; $summary['total'] += (int)$row['count'];
    }
    return ['bookings'=>array_map('booking_data',$rows),'total'=>$total,'page'=>$page,'pageSize'=>$size,'summary'=>$summary];
}
function list_users(array $query): array {
    [$page,$size] = pagination($query); $db = database();
    $total = (int)execute_query($db,"SELECT COUNT(*) FROM users WHERE role='customer'")->fetchColumn();
    $page = min($page,max(1,(int)ceil($total/$size))); $offset = ($page-1)*$size;
    $rows = execute_query($db,"SELECT u.id,u.name,u.email,u.created_at,COUNT(b.id) AS bookings FROM users u LEFT JOIN bookings b ON b.user_id=u.id WHERE u.role='customer' GROUP BY u.id,u.name,u.email,u.created_at ORDER BY u.id DESC LIMIT $size OFFSET $offset")->fetchAll();
    foreach ($rows as &$row) { foreach (['id','created_at','bookings'] as $key) { $row[$key] = (int)$row[$key]; } } unset($row);
    return ['users'=>$rows,'total'=>$total,'page'=>$page,'pageSize'=>$size];
}
function update_booking(array $data, int $id): array {
    $status = $data['status'] ?? ''; $payment = $data['paymentStatus'] ?? ''; $version = $data['version'] ?? null;
    require_value(in_array($status,STATUSES,true),'Select a valid reservation status.');
    require_value(in_array($payment,PAYMENT_STATUSES,true),'Select a valid payment status.');
    require_value(is_int($version),'Missing record version.');
    $result = execute_query(database(),'UPDATE bookings SET status=?,payment_status=?,updated_at=?,version=version+1 WHERE id=? AND version=?',[$status,$payment,time(),$id,$version]);
    require_value($result->rowCount() === 1,'This record changed or no longer exists. Reopen it and try again.',409);
    return ['booking'=>get_booking($id)];
}
