<?php
// Optional: copy this to config.local.php. That file is ignored by git.
if (!defined('SITESEEING')) { http_response_code(403); exit; }
return [
    'site_url' => 'http://localhost/SITEseeing',
    'db_password' => '',
    // Enable these only after composer install and filling your provider's settings.
    // 'email_mode' => 'smtp',
    // 'smtp_host' => 'your-provider-smtp-host',
    // 'smtp_port' => 587,
    // 'smtp_security' => 'starttls',
    // 'smtp_username' => 'your-sender@example.com',
    // 'smtp_password' => 'your-provider-SMTP-password',
    // 'mail_from' => 'your-sender@example.com',
];
