/* Account UI and API integration in a small DOM harness; no live mail or credentials. */
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const base = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(base,'index.html'),'utf8');
const ids = new Set([...html.matchAll(/\bid="([^"]+)"/g)].map(match=>match[1]));
class Element {
    constructor() {this.value='';this.textContent='';this.innerHTML='';this.hidden=false;this.dataset={};this.events={};this.attrs={};this.disabled=false;
        this.classes=new Set();this.classList={toggle:(name,on)=>{on ??= !this.classes.has(name);if(on)this.classes.add(name);else this.classes.delete(name);},contains:name=>this.classes.has(name)};
        this.buttons=[{disabled:false}];
    }
    setAttribute(name,value){this.attrs[name]=value;}
    addEventListener(name,fn){this.events[name]=fn;}
    querySelectorAll(){return this.buttons;}
    reportValidity(){return true;}
    focus(){this.focused=true;}
}
const elements=new Map([...ids].map(id=>[id,new Element()]));
const calls=[],assigned=[],toasts=[],modals=[];
let serverUser=null, nextError=null, serverCsrf='initial', stale=false;
const name='Lu <img src=x onerror=alert(1)>';
const customer={id:1,name,email:'lu@example.test',role:'customer'};
const sandbox={URL,URLSearchParams,console,document:{getElementById:id=>elements.get(id)||null},
    location:{href:'http://localhost/SITEseeing/index.html',assign:url=>assigned.push(url),replace:url=>assigned.push(url)},
    openModal:id=>modals.push(id),closeModal:id=>modals.push('close:'+id),showToast:message=>toasts.push(message),
    resumeReservationAfterLogin:()=>calls.push({resume:true}),
    localStorage:{getItem(){throw new Error('Browser storage must not hold account credentials');},setItem(){throw new Error('Browser storage must not hold account credentials');}},
    fetch:async (url,options)=>{
        const transport = new URL(url);
        assert.equal(transport.pathname, '/SITEseeing/api.php');
        const route = transport.searchParams.get('route');
        calls.push({url:route,options});url=route;let data={},status=200;
        if(nextError){status=nextError.status;data={error:nextError.message};nextError=null;}
        else if(url==='/api/session'){data={user:serverUser,csrf:serverUser?serverCsrf:null,emailMode:'local'};}
        else if(url==='/api/auth/signup'){data={challengeId:'test-challenge',email:'lu@example.test',emailMode:'local'};status=202;}
        else if(url==='/api/auth/resend'){data={emailMode:'local'};}
        else if(url==='/api/auth/verify'){
            const body=JSON.parse(options.body);
            if(body.code!=='123456'){status=400;data={error:'Incorrect verification code.'};}
            else {serverUser=customer;data={user:serverUser,csrf:serverCsrf};}
        }
        else if(url==='/api/auth/login'){
            serverUser=JSON.parse(options.body).role==='admin'?{id:2,name:'Admin',role:'admin'}:customer;
            data={user:serverUser,csrf:serverCsrf};
        }
        else if(url==='/api/auth/logout'){
            if(stale){stale=false;status=403;data={error:'Your session changed. Refresh the page and try again.'};}
            else {serverUser=null;data={user:null,csrf:null};}
        }
        else if(url==='/api/bookings'){data={bookings:[{destination:name,packageName:'Solo',bookingId:'SITE-TEST',date:'2099-01-01',guests:1,status:'Confirmed',paymentStatus:'Awaiting Payment',total:2799}]};}
        return {ok:status<400,status,json:async()=>data};
    }
};
sandbox.window=sandbox;
const context=vm.createContext(sandbox);
for(const name of ['utils.js','api-client.js','account.js'])vm.runInContext(fs.readFileSync(path.join(base,name),'utf8'),context,{filename:name});
const form = async id=>elements.get(id).events.submit({preventDefault(){}});
const values = object=>Object.entries(object).forEach(([id,value])=>elements.get(id).value=value);
(async()=>{
    const auth=sandbox.SITEseeingAuth;await auth.ready;
    assert.equal(elements.get('accountButton').textContent,'Account');
    await auth.openAccount();assert(modals.includes('authModal'));
    values({signupName:name,signupEmail:'lu@example.test',signupPassword:'tourpass123'});
    await form('signupForm');
    assert.equal(auth.getUser(),null,'Signup alone must not log in before verification');
    assert(!elements.get('verifyForm').classes.has('hidden'));
    assert(elements.get('authStatus').textContent.includes('No real email was sent'));
    assert.equal(elements.get('signupPassword').value,'');
    values({verifyCode:'000000'});await form('verifyForm');
    assert.equal(auth.getUser(),null);assert(elements.get('authStatus').textContent.includes('Incorrect'));
    assert.equal(elements.get('verifyForm').buttons[0].disabled,false);
    await elements.get('resendCode').events.click();
    values({verifyCode:'123456'});await form('verifyForm');
    assert.equal(auth.getUser().name,name);assert.equal(elements.get('accountButton').textContent,name);
    assert.equal(elements.get('logoutButton').hidden,false);assert(calls.some(call=>call.resume));
    await auth.openAccount();
    assert(elements.get('myBookings').innerHTML.includes('&lt;img'));
    assert(!elements.get('myBookings').innerHTML.includes('<img'));
    const getBookings=calls.find(call=>call.url==='/api/bookings');
    assert.equal(getBookings.options.credentials,'same-origin');
    assert.equal(getBookings.options.headers['X-CSRF-Token'],'initial');
    stale=true;serverCsrf='renewed';await auth.logout();
    assert.equal(auth.getUser(),null);assert.equal(elements.get('accountButton').textContent,'Account');
    assert(calls.filter(call=>call.url==='/api/auth/logout').some(call=>call.options.headers['X-CSRF-Token']==='renewed'));
    values({loginEmail:'lu@example.test',loginPassword:'wrong'});nextError={status:401,message:'Incorrect password'};
    await form('loginForm');assert.equal(auth.getUser(),null);
    assert(elements.get('authStatus').textContent.includes('Incorrect'));
    values({loginPassword:'tourpass123'});await form('loginForm');assert.equal(auth.getUser().email,'lu@example.test');
    values({adminUsername:'admin',adminPassword:'admin123'});await form('adminForm');
    assert.equal(auth.getUser().role,'admin');assert.equal(assigned.at(-1),'admin.html','Admin opens in the same tab');
    assert.equal(elements.get('adminPassword').value,'');
    assert(calls.every(call=>!call.url||call.options.headers['X-SITEseeing-Request']==='1'));
    console.log('PASS: account name, verified signup gate, code errors/resend, password-field clearing, customer login, logout, same-tab admin login, escaped booking history, and CSRF refresh.');
})().catch(error=>{console.error(error);process.exitCode=1;});
