<?php
if (!defined('SITESEEING')) { http_response_code(403); exit; }
date_default_timezone_set('Asia/Manila');

final class ApiError extends RuntimeException {
    public int $status;
    public function __construct(int $status, string $message) { parent::__construct($message); $this->status = $status; }
}
function require_value(bool $condition, string $message, int $status = 400): void {
    if (!$condition) { throw new ApiError($status, $message); }
}
function field(array $data, string $key, int $max = 120, int $min = 1): string {
    $value = $data[$key] ?? '';
    require_value(is_string($value), "Invalid $key.");
    $value = trim($value);
    require_value(strlen($value) >= $min && strlen($value) <= $max && !preg_match('/[\x00-\x1f]/', $value), "Invalid $key.");
    return $value;
}
function email_field(array $data): string {
    $value = strtolower(field($data, 'email', 254));
    require_value((bool) filter_var($value, FILTER_VALIDATE_EMAIL), 'Enter a valid email address.');
    return $value;
}
function password_field(array $data, string $key = 'password'): string {
    $value = $data[$key] ?? '';
    // PASSWORD_DEFAULT is bcrypt on PHP 8: reject overlong inputs rather than truncate them.
    require_value(is_string($value) && strlen($value) >= 8 && strlen($value) <= 72 && !str_contains($value, "\0"), 'Use a password from 8 to 72 bytes long.');
    return $value;
}
function hash_password(string $value): string { return password_hash($value, PASSWORD_DEFAULT, ['cost' => 12]); }
function safe_password_verify(string $value, string $hash): bool {
    return strlen($value) <= 72 && !str_contains($value, "\0") && password_verify($value, $hash);
}
function execute_query(PDO $db, string $sql, array $params = []): PDOStatement {
    $statement = $db->prepare($sql); $statement->execute($params); return $statement;
}
function transaction(PDO $db, callable $callback) {
    $db->beginTransaction();
    try { $result = $callback(); $db->commit(); return $result; }
    catch (Throwable $error) { if ($db->inTransaction()) { $db->rollBack(); } throw $error; }
}
function config(): array {
    static $settings;
    if ($settings !== null) { return $settings; }
    $settings = require __DIR__ . '/config.php';
    if (is_file(__DIR__ . '/config.local.php')) { $settings = array_replace($settings, require __DIR__ . '/config.local.php'); }
    $site = parse_url($settings['site_url']);
    require_value(is_array($site) && isset($site['scheme'],$site['host']) && in_array($site['scheme'],['http','https'],true), 'Configure a valid site URL.', 503);
    require_value(in_array($settings['email_mode'], ['local','smtp'], true), 'Invalid email mode.', 503);
    if ($settings['production']) {
        require_value(str_starts_with($settings['site_url'], 'https://') && $settings['email_mode'] === 'smtp', 'Production requires HTTPS and SMTP configuration.', 503);
        require_value($settings['admin_initial_password'] !== 'admin123' && strlen($settings['admin_initial_password']) >= 12, 'Set a unique initial production admin password.', 503);
    }
    if ($settings['email_mode'] === 'smtp') {
        require_value($settings['smtp_host'] !== '' && (bool)filter_var($settings['mail_from'], FILTER_VALIDATE_EMAIL), 'Configure the SMTP host and sender address.', 503);
        require_value(in_array($settings['smtp_security'], ['ssl','starttls'], true), 'Invalid SMTP security setting.', 503);
        require_value(is_file(dirname(__DIR__) . '/vendor/autoload.php'), 'Run composer install in the project folder before enabling SMTP.', 503);
    }
    return $settings;
}
function database(): PDO {
    static $db;
    if ($db !== null) { return $db; }
    $c = config();
    require_value((bool)preg_match('/^[A-Za-z0-9_]+$/', $c['db_name']), 'Invalid database name.', 503);
    try {
        $db = new PDO('mysql:host=' . $c['db_host'] . ';port=' . (int)$c['db_port'] . ';dbname=' . $c['db_name'] . ';charset=utf8mb4',
            $c['db_user'], $c['db_password'], [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES => false]);
        $admin = execute_query($db, "SELECT id,must_change_password FROM users WHERE username='admin'")->fetch();
        if (!$admin) {
            execute_query($db, "INSERT IGNORE INTO users(name,username,password_hash,role,verified_at,created_at,must_change_password) VALUES('Admin','admin',?,'admin',?,?,?)",
                [hash_password($c['admin_initial_password']), time(), time(), (int)($c['admin_initial_password'] === 'admin123')]);
        } elseif ($c['production']) {
            require_value(!(bool)$admin['must_change_password'], 'Change the existing default admin password before production.', 503);
        }
        if (execute_query($db,"SELECT value FROM app_settings WHERE name='signup_secret'")->fetchColumn() === false) {
            execute_query($db, "INSERT IGNORE INTO app_settings(name,value) VALUES('signup_secret',?)", [bin2hex(random_bytes(32))]);
        }
    } catch (PDOException $error) {
        error_log('SITEseeing database initialization failed: ' . $error->getCode());
        throw new ApiError(503, 'Start MySQL in XAMPP, import database/siteseeing.sql in phpMyAdmin, and check backend/config.php.');
    }
    return $db;
}
function signature(string $challenge, string $code): string {
    $secret = execute_query(database(), "SELECT value FROM app_settings WHERE name='signup_secret'")->fetchColumn();
    return hash_hmac('sha256', $challenge . ':' . $code, $secret);
}
function rate_limit(string $action, int $maximum = 10, int $seconds = 600, string $identity = ''): void {
    $db = database(); $now = time(); $key = hash('sha256', $action . ':' . ($_SERVER['REMOTE_ADDR'] ?? 'local') . ':' . $identity);
    $allowed = transaction($db, function () use ($db,$key,$now,$maximum,$seconds) {
        execute_query($db, 'INSERT IGNORE INTO rate_limits(`key`,window_start,count) VALUES(?,?,0)', [$key,$now]);
        $row = execute_query($db, 'SELECT * FROM rate_limits WHERE `key`=? FOR UPDATE', [$key])->fetch();
        $count = $row['window_start'] <= $now-$seconds ? 1 : (int)$row['count']+1;
        $start = $row['window_start'] <= $now-$seconds ? $now : $row['window_start'];
        execute_query($db, 'UPDATE rate_limits SET window_start=?,count=? WHERE `key`=?', [$start,$count,$key]);
        return $count <= $maximum;
    });
    require_value($allowed, 'Too many attempts. Please try again later.', 429);
}
function start_app_session(): void {
    $c = config();
    $path = str_replace('\\','/',dirname($_SERVER['SCRIPT_NAME'] ?? '/api.php'));
    if ($path === '.') { $path = '/'; }
    $sessionFolder = $c['private_dir'] . '/sessions';
    if (!is_dir($sessionFolder) && !mkdir($sessionFolder,0700,true) && !is_dir($sessionFolder)) { throw new ApiError(503,'The private session folder is not writable.'); }
    session_save_path($sessionFolder);
    session_name('siteseeing_session');
    ini_set('session.use_strict_mode', '1'); ini_set('session.use_only_cookies', '1'); ini_set('session.gc_maxlifetime', '43200');
    session_set_cookie_params(['lifetime'=>43200,'path'=>rtrim($path,'/') . '/','secure'=>$c['production'],'httponly'=>true,'samesite'=>'Lax']);
    session_start();
}
function current_user(): ?array {
    if (!isset($_SESSION['user_id']) || ($_SESSION['expires'] ?? 0) <= time()) { $_SESSION = []; return null; }
    $row = execute_query(database(), 'SELECT * FROM users WHERE id=?', [$_SESSION['user_id']])->fetch();
    if (!$row || (int)$row['session_version'] !== ($_SESSION['session_version'] ?? 0)) { $_SESSION = []; return null; }
    return $row;
}
function public_user(array $row): array {
    return ['id'=>(int)$row['id'],'name'=>$row['name'],'email'=>$row['email'],'role'=>$row['role'],'mustChangePassword'=>(bool)$row['must_change_password']];
}
function authenticated(?array $user, ?string $role = null): array {
    require_value($user !== null, 'Please log in to continue.', 401);
    require_value($role === null || $user['role'] === $role, 'This action is not available to your account.', 403);
    return $user;
}
function login_session(array $user): array {
    session_regenerate_id(true);
    $_SESSION = ['user_id'=>(int)$user['id'],'session_version'=>(int)$user['session_version'],'expires'=>time()+43200,'csrf'=>bin2hex(random_bytes(32))];
    return ['user'=>public_user($user),'csrf'=>$_SESSION['csrf']];
}
function read_request(?array $user): array {
    require_value(($_SERVER['HTTP_X_SITESEEING_REQUEST'] ?? '') === '1', 'Invalid request origin.', 403);
    $site = parse_url(config()['site_url']);
    $origin = $site['scheme'] . '://' . $site['host'] . (isset($site['port']) ? ':' . $site['port'] : '');
    require_value(empty($_SERVER['HTTP_ORIGIN']) || rtrim($_SERVER['HTTP_ORIGIN'],'/') === $origin, 'Invalid request origin.', 403);
    if ($user !== null) { require_value(hash_equals($_SESSION['csrf'] ?? '', $_SERVER['HTTP_X_CSRF_TOKEN'] ?? ''), 'Your session changed. Refresh the page and try again.', 403); }
    require_value(str_starts_with($_SERVER['CONTENT_TYPE'] ?? '', 'application/json'), 'Send JSON data.', 415);
    $raw = file_get_contents('php://input', false, null, 0, 16385);
    require_value(is_string($raw) && strlen($raw) > 0 && strlen($raw) <= 16384, 'Request body is too large or missing.', 413);
    try { $data = json_decode($raw, true, 512, JSON_THROW_ON_ERROR); }
    catch (JsonException $error) { throw new ApiError(400,'Invalid JSON data.'); }
    require_value(is_array($data) && str_starts_with(ltrim($raw), '{'), 'Send a JSON object.');
    return $data;
}
function packages(): array {
    static $catalog;
    if ($catalog !== null) { return $catalog; }
    $source = file_get_contents(dirname(__DIR__) . '/packages.js');
    $source = preg_replace('/^\s*\/\/[^\n]*\n/', '', $source);
    require_value((bool)preg_match('/^\s*window\.SITESEEING_PACKAGES\s*=\s*(\[.*\])\s*;\s*$/s', $source, $match), 'Invalid package catalog.', 503);
    $entries = json_decode($match[1], true, 512, JSON_THROW_ON_ERROR); $catalog = [];
    foreach ($entries as $item) {
        require_value(is_int($item['price']) && $item['price'] > 0 && $item['price'] <= 9007199254740, 'Invalid package price.', 503);
        require_value((bool)preg_match('/^[a-z0-9-]+$/', $item['id']) && !isset($catalog[$item['id']]), 'Invalid package ID.', 503);
        $catalog[$item['id']] = $item;
    }
    return $catalog;
}
